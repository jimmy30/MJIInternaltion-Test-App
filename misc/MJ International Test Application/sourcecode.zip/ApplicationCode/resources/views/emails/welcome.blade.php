<div> Welcome {!! html_entity_decode($email->name) !!} </div>
<div> Thanks for registering with us! </div>
